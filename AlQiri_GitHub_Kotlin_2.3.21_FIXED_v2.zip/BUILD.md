# Build on GitHub

The GitHub Actions workflows intentionally do **not** use `android-actions/setup-android`.
GitHub-hosted Ubuntu runners already include the Android SDK; the workflow only uses
`sdkmanager` to ensure API 34 and Build Tools 34.0.0 are installed. This avoids the
obsolete `tools` package failure seen in September 2026.
