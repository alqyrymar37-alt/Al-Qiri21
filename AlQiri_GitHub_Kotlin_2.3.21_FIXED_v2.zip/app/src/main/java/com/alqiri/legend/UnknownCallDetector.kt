package com.alqiri.legend

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract.PhoneLookup
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Detects unknown/new incoming numbers as the phone rings and looks them up automatically
 * (Yemeni carrier + whether they called before), no request needed from the user.
 * It never guesses who a stranger is — that would take a private database we don't have (see chat).
 * Toggle: SecureStore.callDetectorOn(). Registered in the manifest for android.intent.action.PHONE_STATE.
 */
class UnknownCallDetector : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (!SecureStore.callDetectorOn(context)) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)?.trim()
        if (number.isNullOrBlank()) return

        if (isSavedContact(context, number)) return  // known contact: nothing to detect

        val tools = PhoneTools(context.applicationContext, { }, { false })
        val result = try { tools.lookupCallerID(number) } catch (e: Exception) { return }
        notify(context, number, result)
    }

    private fun isSavedContact(context: Context, number: String): Boolean {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return false
        return try {
            val uri = Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            context.contentResolver.query(uri, arrayOf(PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { it.moveToFirst() } ?: false
        } catch (e: Exception) { false }
    }

    private fun notify(context: Context, number: String, body: String) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel("unknown_calls", "كاشف الارقام المجهولة", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            context, number.hashCode(), Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, "unknown_calls")
            .setSmallIcon(R.drawable.ic_qiri_mono)
            .setContentTitle("📵 رقم مجهول يتصل: $number")
            .setContentText(body.lineSequence().firstOrNull { it.startsWith("📡") } ?: "اضغط للتفاصيل")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { nm.notify(number.hashCode(), n) } catch (_: SecurityException) {}
    }
}
