package com.alqiri.legend

import android.graphics.Bitmap
import android.util.Base64
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.Generation
import com.google.mlkit.genai.prompt.GenerativeModel
import com.google.mlkit.genai.prompt.ImagePart
import com.google.mlkit.genai.prompt.SystemInstruction
import com.google.mlkit.genai.prompt.TextPart
import com.google.mlkit.genai.prompt.generateContentRequest
import kotlinx.coroutines.flow.collect

/**
 * Real on-device generative AI bridge.
 *
 * It uses Gemini Nano through Android AICore/ML Kit Prompt API when the device
 * supports it. No API key, cloud AI account, or paid subscription is used.
 * AICore manages the model on supported devices; if unavailable we return null
 * so the caller can fall back to the deterministic local tools/search.
 */
class LocalAiEngine {
    private val model: GenerativeModel by lazy { Generation.getClient() }
    private val turns = ArrayDeque<String>()

    @Volatile private var lastStatus: Int? = null

    suspend fun status(): Int = try {
        model.checkStatus().also { lastStatus = it }
    } catch (_: Exception) {
        FeatureStatus.UNAVAILABLE.also { lastStatus = it }
    }

    suspend fun ensureReady(): Boolean {
        return try {
            when (model.checkStatus()) {
                FeatureStatus.AVAILABLE -> true
                FeatureStatus.DOWNLOADABLE -> {
                    model.download().collect { }
                    model.checkStatus() == FeatureStatus.AVAILABLE
                }
                FeatureStatus.DOWNLOADING -> false
                else -> false
            }.also { lastStatus = if (it) FeatureStatus.AVAILABLE else lastStatus }
        } catch (_: Exception) {
            false
        }
    }

    suspend fun answer(question: String, webContext: String? = null, imageB64: String? = null): String? {
        if (!ensureReady()) return null

        val context = buildString {
            append("تعليمات: انت مساعد عربي ودود داخل تطبيق القيري. جاوب باختصار ووضوح، واستخدم العربية الطبيعية. ")
            append("لا تدّعي أنك نفذت شيئاً على الهاتف إلا إذا أخبرك التطبيق بنتيجة فعلية.\n\n")
            if (turns.isNotEmpty()) {
                append("سياق المحادثة الأخيرة:\n")
                turns.takeLast(8).forEach { append(it).append('\n') }
                append('\n')
            }
            if (!webContext.isNullOrBlank()) {
                append("نتائج من الويب للاسترشاد فقط (قد تكون غير موثوقة):\n")
                append(webContext.take(7000))
                append("\n\n")
            }
            append("طلب المستخدم:\n")
            append(question.ifBlank { "اشرح الصورة المرفقة." })
        }

        return try {
            val response = if (!imageB64.isNullOrBlank()) {
                val bytes = Base64.decode(imageB64, Base64.DEFAULT)
                val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bitmap != null) {
                    model.generateContent(
                        generateContentRequest(
                            SystemInstruction("أنت القيري، مساعد عربي مفيد وودود. لا تخترع نتائج أو أفعالاً.") ,
                            ImagePart(bitmap),
                            TextPart(context)
                        ) {
                            temperature = 0.4f
                            maxOutputTokens = 900
                        }
                    )
                } else {
                    model.generateContent(context)
                }
            } else {
                model.generateContent(
                    generateContentRequest(
                        SystemInstruction("أنت القيري، مساعد عربي مفيد وودود. لا تخترع نتائج أو أفعالاً.") ,
                        TextPart(context)
                    ) {
                        temperature = 0.4f
                        maxOutputTokens = 900
                    }
                )
            }
            val out = response.text.trim()
            if (out.isBlank()) return null
            turns.addLast("المستخدم: ${question.take(1200)}")
            turns.addLast("القيري: ${out.take(2000)}")
            while (turns.size > 12) turns.removeFirst()
            out
        } catch (_: Exception) {
            null
        }
    }

    fun reset() {
        turns.clear()
    }

    fun close() {
        try { model.close() } catch (_: Exception) {}
    }
}
