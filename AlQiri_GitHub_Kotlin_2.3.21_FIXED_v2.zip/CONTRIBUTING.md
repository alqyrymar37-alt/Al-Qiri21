# Contributing to AlQiri

Thank you for helping improve AlQiri.

## Development

- Android Studio Ladybug or newer is recommended.
- JDK 17.
- Android SDK 34.
- Minimum Android version: API 26.

### Build

```bash
gradle :app:assembleDebug
```

### Pull requests

1. Create a focused branch.
2. Keep changes small and explain user-facing behavior.
3. Do not commit API keys, tokens, certificates, keystores, or private data.
4. Test on at least one Android device/emulator when possible.
5. Update documentation when behavior or permissions change.

## Privacy-sensitive changes

Changes involving contacts, calls, SMS, microphone, camera, location, accessibility, or background services must explain why the permission is needed and how the user can disable the feature.
