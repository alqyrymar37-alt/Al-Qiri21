# GitHub Actions

The build workflows intentionally do not run `android-actions/setup-android`.
GitHub-hosted Ubuntu runners already provide an Android SDK. This avoids a
known class of failures caused by outdated/deprecated SDK package setup.

Run **Actions → Build AlQiri APK → Run workflow** to build the debug APK.
